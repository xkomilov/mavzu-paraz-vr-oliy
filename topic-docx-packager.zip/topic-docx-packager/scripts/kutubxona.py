#!/usr/bin/env python3
# topic-docx-packager: xayrullokomilov.uz/kutubxona sayt kutubxonasidan foydalanish.
# Sayt ochiq JSON API beradi (kirish talab qilinmaydi):
#   GET /api/katalog                                  -> bo'limlar va mavzular (id, nomi, soni)
#   GET /api/materiallar?sahifa=N&q=...&bolim=..&mavzu=..  -> {jami, sahifaHajmi(20), materiallar:[{id,nomi,mavzular,faylBor,faylHajmi,...}]}
#   GET /api/materiallar/<id>/fayl?yuklab=1           -> fayl (PDF / PPTX / DOCX), Content-Type bilan
# Fayllar OCR qilingan, PDF matn qatlami PyMuPDF bilan o'qiladi.
#
# O'rnatish (site-packages yozilmasa --target ishlating):
#   python3 -m pip install --target <papka>/pylib pymupdf python-docx
#   PYTHONPATH=<papka>/pylib python3 kutubxona.py ...
#
# Buyruqlar:
#   katalog  --work W                       -> W/catalog.json (barcha materiallar metama'lumoti)
#   tanla    --work W [--regex R] [--mavzu "nomi" ...]   -> W/selected.json (fayli bor, mos materiallar)
#   yukla    --work W [--jobs 6]            -> W/lib/<id> (+ <id>.ct); mavjudlari o'tkazib yuboriladi
#   matn     --work W                       -> W/txt/<id>.txt (PDF/PPTX/DOCX dan matn, sahifa belgisi bilan)
#   qidir    --work W "so'z1|so'z2" [--n 20] -> lokal txt bo'yicha qidiruv: id, nom, mos sahifalar, parcha
#   qidir-sayt "so'z"                        -> saytning o'z qidiruvi (/api/materiallar?q=)
import argparse, json, os, re, sys, urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor

BASE = 'https://xayrullokomilov.uz'
UA = {'User-Agent': 'Mozilla/5.0'}


def get_json(url):
    req = urllib.request.Request(url, headers=UA)
    return json.load(urllib.request.urlopen(req, timeout=60))


def cmd_katalog(a):
    allm, p = {}, 1
    while True:
        j = get_json(f'{BASE}/api/materiallar?sahifa={p}')
        for m in j['materiallar']:
            allm[m['id']] = m
        if not j['materiallar'] or len(allm) >= j['jami']:
            break
        p += 1
    os.makedirs(a.work, exist_ok=True)
    json.dump(list(allm.values()), open(os.path.join(a.work, 'catalog.json'), 'w'), ensure_ascii=False)
    print('materiallar:', len(allm))


DEFAULT_RE = (r'паразит|parazit|безгак|bezgak|маляри|malari|гельмин|gelmint|гижж|gijj|лейшман|leyshman|leishman|'
              r'эхинокок|exinokok|лямбли|lambli|энтомол|entomol|чивин|chivin|комар|москит|трихин|аскарид|askarid|'
              r'токсоплаз|toksoplaz|описторх|fasciol|фасциол|энтеробиоз|enterobioz|педикул|pedikul|чесотк|скабиоз|'
              r'криптоспор|дезинсек|dezinsek|дератиз|deratiz|амёб|амеб|балантид|giardi')
DEFAULT_MAVZU = ['Parazitologiya va entomologiya boʻlimi', 'Parazitologiya laboratoriyasi']


def cmd_tanla(a):
    c = json.load(open(os.path.join(a.work, 'catalog.json')))
    rx = re.compile(a.regex or DEFAULT_RE, re.I)
    mv = set(a.mavzu or DEFAULT_MAVZU)
    sel = [m for m in c if m.get('faylBor') and (rx.search(m['nomi']) or any(t['nomi'] in mv for t in m['mavzular']))]
    json.dump(sel, open(os.path.join(a.work, 'selected.json'), 'w'), ensure_ascii=False)
    print('tanlandi:', len(sel), 'hajm MB:', round(sum(m.get('faylHajmi') or 0 for m in sel) / 1e6, 1))


def cmd_yukla(a):
    sel = json.load(open(os.path.join(a.work, 'selected.json')))
    os.makedirs(os.path.join(a.work, 'lib'), exist_ok=True)

    def dl(m):
        out = os.path.join(a.work, 'lib', str(m['id']))
        if os.path.exists(out):
            return
        try:
            r = urllib.request.urlopen(urllib.request.Request(
                f'{BASE}/api/materiallar/{m["id"]}/fayl?yuklab=1', headers=UA), timeout=300)
            data = r.read()
            open(out, 'wb').write(data)
            open(out + '.ct', 'w').write(r.headers.get('content-type') or '')
        except Exception as e:
            print('XATO', m['id'], e)

    with ThreadPoolExecutor(a.jobs) as ex:
        list(ex.map(dl, sel))
    print('yuklandi')


def extract(path, ct):
    if 'pdf' in ct:
        import pymupdf
        d = pymupdf.open(path)
        return '\n'.join(f'\n=== sahifa {i + 1} ===\n' + p.get_text() for i, p in enumerate(d))
    if 'presentation' in ct:
        import zipfile
        z = zipfile.ZipFile(path)
        sl = sorted([n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)],
                    key=lambda n: int(re.findall(r'\d+', n)[-1]))
        out = []
        for n in sl:
            x = z.read(n).decode('utf8', 'ignore')
            out.append(f'\n=== slayd {re.findall(r"[0-9]+", n)[-1]} ===\n' + ' '.join(re.findall(r'<a:t>(.*?)</a:t>', x)))
        return '\n'.join(out)
    if 'wordprocessing' in ct:
        import zipfile, html
        x = zipfile.ZipFile(path).read('word/document.xml').decode('utf8', 'ignore')
        paras = [''.join(re.findall(r'<w:t[^>]*>(.*?)</w:t>', p)) for p in re.findall(r'<w:p[ >].*?</w:p>', x, re.S)]
        return html.unescape('\n'.join(p for p in paras if p.strip()))
    return ''


def cmd_matn(a):
    sel = {m['id']: m for m in json.load(open(os.path.join(a.work, 'selected.json')))}
    os.makedirs(os.path.join(a.work, 'txt'), exist_ok=True)
    idx = {}
    for i, m in sel.items():
        p = os.path.join(a.work, 'lib', str(i))
        if not os.path.exists(p):
            continue
        ct = open(p + '.ct').read() if os.path.exists(p + '.ct') else 'pdf'
        t = os.path.join(a.work, 'txt', f'{i}.txt')
        if not os.path.exists(t):
            try:
                open(t, 'w').write(extract(p, ct))
            except Exception as e:
                print('XATO', i, e)
                continue
        idx[i] = {'nomi': m['nomi'], 'belgi': len(open(t).read())}
    json.dump(idx, open(os.path.join(a.work, 'index.json'), 'w'), ensure_ascii=False, indent=0)
    bo = [i for i, v in idx.items() if v['belgi'] < 200]
    print('matn:', len(idx), 'matnsiz (OCR yo\'q):', bo)


def cmd_qidir(a):
    # index.json ga bog'liq emas: txt/ dagi barcha fayllar katalog nomlari bilan qidiriladi
    cat = {str(m['id']): m['nomi'] for m in json.load(open(os.path.join(a.work, 'catalog.json')))}
    idx = {f[:-4]: {'nomi': cat.get(f[:-4], '')} for f in os.listdir(os.path.join(a.work, 'txt')) if f.endswith('.txt')}
    rx = re.compile(a.sorov, re.I)
    res = []
    for i, v in idx.items():
        t = open(os.path.join(a.work, 'txt', f'{i}.txt')).read()
        hits = list(rx.finditer(t))
        if hits:
            pages = sorted({len(re.findall(r'=== (?:sahifa|slayd) ', t[:h.start()])) for h in hits[:200]})
            s = hits[0].start()
            res.append((len(hits), i, v['nomi'], pages[:15], t[max(0, s - 150):s + 250].replace('\n', ' ')))
    for n, i, nomi, pages, snip in sorted(res, reverse=True)[:a.n]:
        print(f'[{i}] {n} ta | {nomi[:100]} | sahifa: {pages}\n    ...{snip}...\n')


def cmd_bitta(a):
    """Katalogdagi istalgan materialni ID bo'yicha yuklab, matnini txt/ ga yozadi va index.json ga qo'shadi."""
    cat = {m['id']: m for m in json.load(open(os.path.join(a.work, 'catalog.json')))}
    idxp = os.path.join(a.work, 'index.json')
    idx = json.load(open(idxp)) if os.path.exists(idxp) else {}
    for i in a.ids:
        p = os.path.join(a.work, 'lib', str(i))
        try:
            if not os.path.exists(p):
                r = urllib.request.urlopen(urllib.request.Request(
                    f'{BASE}/api/materiallar/{i}/fayl?yuklab=1', headers=UA), timeout=300)
                open(p, 'wb').write(r.read())
                open(p + '.ct', 'w').write(r.headers.get('content-type') or '')
            t = os.path.join(a.work, 'txt', f'{i}.txt')
            if not os.path.exists(t):
                open(t, 'w').write(extract(p, open(p + '.ct').read()))
            idx[str(i)] = {'nomi': cat.get(i, {}).get('nomi', ''), 'belgi': len(open(t).read())}
            print('OK', i, idx[str(i)]['nomi'][:90], idx[str(i)]['belgi'])
        except Exception as e:
            print('XATO', i, e)
    json.dump(idx, open(idxp, 'w'), ensure_ascii=False, indent=0)


def cmd_qidir_sayt(a):
    j = get_json(f'{BASE}/api/materiallar?q={urllib.parse.quote(a.sorov)}')
    print('jami:', j['jami'])
    for m in j['materiallar']:
        print(m['id'], m['nomi'][:120])


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest='cmd', required=True)
    for n in ['katalog', 'tanla', 'yukla', 'matn', 'qidir']:
        s = sp.add_parser(n)
        s.add_argument('--work', required=True)
        if n == 'tanla':
            s.add_argument('--regex')
            s.add_argument('--mavzu', nargs='*')
        if n == 'yukla':
            s.add_argument('--jobs', type=int, default=6)
        if n == 'qidir':
            s.add_argument('sorov')
            s.add_argument('--n', type=int, default=20)
    s = sp.add_parser('qidir-sayt')
    s.add_argument('sorov')
    s = sp.add_parser('bitta')
    s.add_argument('--work', required=True)
    s.add_argument('ids', nargs='+', type=int)
    a = ap.parse_args()
    {'katalog': cmd_katalog, 'tanla': cmd_tanla, 'yukla': cmd_yukla, 'matn': cmd_matn,
     'qidir': cmd_qidir, 'qidir-sayt': cmd_qidir_sayt, 'bitta': cmd_bitta}[a.cmd](a)
