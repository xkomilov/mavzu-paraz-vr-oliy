#!/usr/bin/env python3
# topic-docx-packager: check_outputs.ps1 ning Python (Linux/macOS) varianti, builder'dan mustaqil tekshiruv.
#   python3 check_outputs.py --dir <natija-papkasi> [--min 800] [--expected N]
# Tekshiruvlar: nom (NNN.docx), "Foydalanilgan adabiyotlar" bo'limi, asosiy matn so'zlari (sarlavha va
# adabiyotlar hisobga kirmaydi), [n] havolalar va adabiyot raqamlari mosligi, apostroflar.
import argparse, html, os, re, sys, zipfile

APOS = re.compile('[\u2019\u2018\u02BB\u02BC\u00B4`]')
CITE = re.compile(r'\[(\d+(?:\s*[,;\u2013-]\s*\d+)*)\]')


def paras(path):
    x = zipfile.ZipFile(path).read('word/document.xml').decode('utf8')
    out = []
    for p in re.findall(r'<w:p[ >].*?</w:p>', x, re.S):
        p = p.replace('<w:tab/>', '\t')
        t = html.unescape(''.join(re.findall(r'<w:t(?: [^>]*)?>(.*?)</w:t>', p, re.S))).strip()
        if t:
            out.append(t)
    return out


def check(path, mn):
    notes = []
    name = os.path.basename(path)
    if not re.match(r'^\d{3}\.docx$', name):
        notes.append('nom NNN.docx emas')
    try:
        ps = paras(path)
    except Exception as e:
        return name, '', 0, 0, 'XATO', f"o'qilmadi: {e}"
    ri = next((i for i in range(1, len(ps)) if ps[i].startswith('Foydalanilgan adabiyotlar')), -1)
    if ri < 0:
        notes.append("'Foydalanilgan adabiyotlar' bo'limi yo'q")
        body, refs = ps[1:], []
    else:
        body, refs = ps[1:ri], ps[ri + 1:]
    words = sum(len(l.split()) for l in body)
    nref = len([r for r in refs if re.match(r'^\[\d+\]', r)])
    text = ' '.join(body)
    if words < mn:
        notes.append(f"so'z {words} < {mn}")
    if nref == 0:
        notes.append("adabiyot yozuvlari yo'q")
    if APOS.search(text):
        notes.append("noto'g'ri apostrof")
    cited = set()
    for m in CITE.finditer(text):
        for tk in re.split(r'\s*[,;]\s*', m.group(1)):
            r = [int(v) for v in re.split(r'\s*[\u2013-]\s*', tk)]
            cited.update(range(r[0], r[1] + 1) if len(r) == 2 else r)
    for c in sorted(cited):
        if c < 1 or c > nref:
            notes.append(f"[{c}] adabiyotda yo'q")
    unused = [k for k in range(1, nref + 1) if k not in cited]
    if unused:
        notes.append('ishlatilmagan manba: ' + ', '.join(map(str, unused)))
    hard = [n for n in notes if not n.startswith('ishlatilmagan')]
    status = 'XATO' if hard else ('OGOH' if notes else 'OK')
    return name, (ps[0][:40] if ps else ''), words, nref, status, '; '.join(notes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--min', type=int, default=800)
    ap.add_argument('--expected', type=int, default=0)
    a = ap.parse_args()
    files = sorted(f for f in os.listdir(a.dir) if f.endswith('.docx') and not f.startswith('~$'))
    rows = [check(os.path.join(a.dir, f), a.min) for f in files]
    problems = sum(1 for r in rows if r[4] == 'XATO')
    for r in rows:
        print(f'{r[0]}  {r[2]:5d} so\'z  {r[3]:3d} manba  {r[4]:4s}  {r[1]}  {r[5]}')
    print(f'Jami fayl: {len(files)}')
    if rows:
        print(f"So'z: min {min(r[2] for r in rows)}, max {max(r[2] for r in rows)}")
    if a.expected:
        if len(files) == a.expected:
            print(f'Kutilgan {a.expected} ta fayl: mos')
        else:
            print(f'DIQQAT: kutilgan {a.expected}, mavjud {len(files)}')
            problems += 1
    if problems:
        print(f'Xatolar bor: {problems}')
        sys.exit(1)
    print("Barcha tekshiruvlar o'tdi (XATO yo'q).")


if __name__ == '__main__':
    main()
