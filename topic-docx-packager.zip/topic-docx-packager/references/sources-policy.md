# Manba siyosati (topic-docx-packager)

Maqsad: har bir mavzu matni faqat **haqiqiy va tekshirilgan** manbalarga tayansin. Tekshirib bo'lmagan narsa matnga "fakt" sifatida kirmaydi.

## 1. Manbalar ustuvorligi

Yuqoridagi manba ishonchliroq; pastdagilari to'ldiradi.

1. **Foydalanuvchi kutubxonasi** (seans boshida berilgan papka, masalan `D:\KUTUBXONA`). Avval shu papkadagi barcha hujjatlar ko'rib chiqiladi (darslik, qo'llanma, sanPiN, MU/MUK, buyruqlar, normativlar, rasmiy hujjatlar). Mavzuga tegishli bo'lim topilmasa, buni hisobotda yozing.
2. **O'zbekiston rasmiy hujjatlari**: qonunlar, Vazirlar Mahkamasi qarorlari, Sog'liqni saqlash vazirligi buyruqlari, SanPiN, MU (metodik ko'rsatma), MUK (metodik ko'rsatma/ko'rsatma-kollegiya), normativ hujjatlar. Rasmiy bazalar: lex.uz va vazirlik saytlari.
3. **Xalqaro rasmiy tashkilotlar**: JSST (WHO) qo'llanmalari va hisobotlari, CDC (masalan DPDx), boshqa tashkilot qo'llanmalari.
4. **Xalqaro darsliklar va monografiyalar**: muallif, nashr, yil, nashr raqami. Soha bo'yicha klassik darsliklar (masalan parazitologiya bo'yicha Garcia, Manson; ruscha klassik darsliklar, masalan Genis) — soha va mavzuga mosini tanlang.
5. **Hakamlanadigan ilmiy maqolalar**: faqat DOI bilan tekshirilgani.

Soha boshqa bo'lsa (masalan, kardiologiya, farmakologiya), ro'yxat mos ravishda o'zgaradi: 1-band (kutubxona) va 2-band (milliy normativlar) saqlanadi, 3–5 bandlar sohaga moslanadi.

## 2. Tekshirish qoidalari (majburiy)

- **DOI**: matnga kiritishdan oldin tekshiriladi (WebSearch/WebFetch orqali doi.org yoki nashriyot sahifasi). Tasdiqlanmasa — DOI yozilmaydi, manba "tasdiqlanmagan" deb belgilanadi.
- **JSST raqamlari va hujjat nomlari**: WHO saytida yoki qidiruvda tekshiriladi. Topilmasa "tasdiqlanmagan".
- **O'zbekistonga xos ma'lumotlar** (muddat, shakl raqami, hudud, buyruq raqami, me'yor qiymati): agar tasdiqlay olmasangiz, **taxmin qilmang** va matnga kiritmang. Uni `_build/tasdiqlanmagan.md` va hisobotning "Tasdiqlanmagan faktlar" ro'yxatiga yozing. Maqolada «Tasdiqlanmagan ma'lumotlar» bo'limi bo'lmaydi (SKILL.md 3.2).
- **Mos manba topilmasa**: matnda ochiq yozing, masalan "Mazkur jihat bo'yicha tekshiriladigan manba topilmadi". Soxta yoki taxminiy havola qo'ymang.
- **Iqtibos**: qisqa va tirnoq ichida, manba raqami bilan. Bir iqtibos 15 so'zdan oshmasin. Uzun parchalar ko'chirilmaydi.
- **Rasmiy manbalar bir-biridan farq qilsa** (masalan, JSST va milliy me'yor boshqacha raqam bersa): ikkalasini ham matnda ko'rsating va hisobotning "Farq qiladigan joylar" bo'limiga yozing. Birini tanlab, ikkinchisini yashirmang.

## 3. Adabiyotlar ro'yxati formati

Har bir yozuv `[n]` bilan boshlanadi (builder yo'q bo'lsa avtomatik qo'shadi) va quyidagilarni o'z ichiga oladi:

- muallif (yoki tashkilot), asar nomi, nashriyot/tashkilot, yil;
- DOI yoki URL — faqat tekshirilgan bo'lsa;
- tasdiqlanmagan manba bo'lsa, oxiriga: `[tasdiqlanmagan]`.

Matnda har bir `[n]` ro'yxatda bo'lishi kerak; ro'yxatdagi har bir manba kamida bir marta matnda ishlatilishi kerak (check_outputs.ps1 buni tekshiradi).

## 4. Taqiqlar

- Muallif, DOI, sahifa raqami, jurnal nomi "o'ylab topish" (fabricate) taqiqlanadi.
- Manbada yo'q raqamni "rasmiy" deb yozish taqiqlanadi.
- Tasdiqlanmagan manbani "tekshirilgan" deb ko'rsatish taqiqlanadi.
